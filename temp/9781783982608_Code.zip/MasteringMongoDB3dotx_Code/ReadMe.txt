The commands are provided in the scripts.txt file.
Chapters for which scripts are not provided:
1, 4, 10, 12

Chapter 1 does not have any commands.
Chapter 4 has the required files in code bundle.
Chapter 10 and 12 have illustrative snippets.

Other required files for chapters 4, 5, 9 are in their chapter specific folders.

The data dump folder contains the database and collections used. Use mongorestore to use them.