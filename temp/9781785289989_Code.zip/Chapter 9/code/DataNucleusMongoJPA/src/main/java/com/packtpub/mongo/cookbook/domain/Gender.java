/**
 *
 */
package com.packtpub.mongo.cookbook.domain;

/**
 * @author Amol
 *
 */
public enum Gender {
	Male, Female;
}
